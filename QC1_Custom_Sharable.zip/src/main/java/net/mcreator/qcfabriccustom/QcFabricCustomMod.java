/*
 *	MCreator note:
 *
 *	If you lock base mod element files, you can edit this file and the proxy files
 *	and they won't get overwritten. If you change your mod package or modid, you
 *	need to apply these changes to this file MANUALLY.
 *
 *
 *	If you do not lock base mod element files in Workspace settings, this file
 *	will be REGENERATED on each build.
 *
 */
package net.mcreator.qcfabriccustom;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import net.mcreator.qcfabriccustom.init.QcFabricCustomModTabs;
import net.mcreator.qcfabriccustom.init.QcFabricCustomModPotions;
import net.mcreator.qcfabriccustom.init.QcFabricCustomModPaintings;
import net.mcreator.qcfabriccustom.init.QcFabricCustomModItems;
import net.mcreator.qcfabriccustom.init.QcFabricCustomModFeatures;
import net.mcreator.qcfabriccustom.init.QcFabricCustomModBrewingRecipes;
import net.mcreator.qcfabriccustom.init.QcFabricCustomModBlocks;

import net.fabricmc.api.ModInitializer;

public class QcFabricCustomMod implements ModInitializer {
	public static final Logger LOGGER = LogManager.getLogger();
	public static final String MODID = "qc_fabric_custom";

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing QcFabricCustomMod");

		QcFabricCustomModTabs.load();

		QcFabricCustomModPotions.load();

		QcFabricCustomModBlocks.load();
		QcFabricCustomModItems.load();

		QcFabricCustomModFeatures.load();
		QcFabricCustomModPaintings.load();

		QcFabricCustomModBrewingRecipes.load();

	}
}
