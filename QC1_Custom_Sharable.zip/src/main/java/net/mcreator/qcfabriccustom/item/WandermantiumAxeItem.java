
package net.mcreator.qcfabriccustom.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;

import net.mcreator.qcfabriccustom.init.QcFabricCustomModTabs;
import net.mcreator.qcfabriccustom.init.QcFabricCustomModItems;

public class WandermantiumAxeItem extends AxeItem {
	public WandermantiumAxeItem() {
		super(new Tier() {
			public int getUses() {
				return 1800;
			}

			public float getSpeed() {
				return 10f;
			}

			public float getAttackDamageBonus() {
				return 6f;
			}

			public int getLevel() {
				return 5;
			}

			public int getEnchantmentValue() {
				return 35;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(QcFabricCustomModItems.WANDERMANTIUM_INGOT));
			}
		}, 1, -2.4f, new Item.Properties().tab(QcFabricCustomModTabs.TAB_QC_1_CUSTOM));
	}
}
