/*
* MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.qcfabriccustom.init;

import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.alchemy.PotionBrewing;

public class QcFabricCustomModBrewingRecipes {
	public static void load() {
		PotionBrewing.addMix(Potions.AWKWARD, QcFabricCustomModItems.WANDERMANTIUM_INGOT, QcFabricCustomModPotions.WANDERING);
	}
}
