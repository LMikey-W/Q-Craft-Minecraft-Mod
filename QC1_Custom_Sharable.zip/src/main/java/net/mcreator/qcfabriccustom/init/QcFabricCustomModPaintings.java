
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.qcfabriccustom.init;

import net.minecraft.world.entity.decoration.PaintingVariant;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.qcfabriccustom.QcFabricCustomMod;

public class QcFabricCustomModPaintings {
	public static void load() {
		Registry.register(Registry.PAINTING_VARIANT, new ResourceLocation(QcFabricCustomMod.MODID, "herobrine_painting"), new PaintingVariant(64, 48));
	}
}
