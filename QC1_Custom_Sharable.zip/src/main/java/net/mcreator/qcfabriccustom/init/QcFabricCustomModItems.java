
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.qcfabriccustom.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.qcfabriccustom.item.WandermantiumSwordItem;
import net.mcreator.qcfabriccustom.item.WandermantiumShovelItem;
import net.mcreator.qcfabriccustom.item.WandermantiumPickaxeItem;
import net.mcreator.qcfabriccustom.item.WandermantiumIngotItem;
import net.mcreator.qcfabriccustom.item.WandermantiumHoeItem;
import net.mcreator.qcfabriccustom.item.WandermantiumAxeItem;
import net.mcreator.qcfabriccustom.item.WandermantiumArmorItem;
import net.mcreator.qcfabriccustom.item.RawWandermantiumItem;
import net.mcreator.qcfabriccustom.item.ChocyMilkItem;
import net.mcreator.qcfabriccustom.QcFabricCustomMod;

public class QcFabricCustomModItems {
	public static Item WANDERMANTIUM_BLOCK;
	public static Item WANDERMANTIUM_ORE;
	public static Item WANDERMANTIUM_INGOT;
	public static Item RAW_WANDERMANTIUM;
	public static Item DEEPSLATE_WANDERMANTIUM_ORE;
	public static Item WANDERMANTIUM_AXE;
	public static Item WANDERMANTIUM_PICKAXE;
	public static Item WANDERMANTIUM_SWORD;
	public static Item WANDERMANTIUM_SHOVEL;
	public static Item WANDERMANTIUM_HOE;
	public static Item WANDERMANTIUM_ARMOR_HELMET;
	public static Item WANDERMANTIUM_ARMOR_CHESTPLATE;
	public static Item WANDERMANTIUM_ARMOR_LEGGINGS;
	public static Item WANDERMANTIUM_ARMOR_BOOTS;
	public static Item CHOCY_MILK;

	public static void load() {
		WANDERMANTIUM_BLOCK = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_block"),
				new BlockItem(QcFabricCustomModBlocks.WANDERMANTIUM_BLOCK, new Item.Properties().tab(QcFabricCustomModTabs.TAB_QC_1_CUSTOM)));
		WANDERMANTIUM_ORE = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_ore"),
				new BlockItem(QcFabricCustomModBlocks.WANDERMANTIUM_ORE, new Item.Properties().tab(QcFabricCustomModTabs.TAB_QC_1_CUSTOM)));
		WANDERMANTIUM_INGOT = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_ingot"), new WandermantiumIngotItem());
		RAW_WANDERMANTIUM = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "raw_wandermantium"), new RawWandermantiumItem());
		DEEPSLATE_WANDERMANTIUM_ORE = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "deepslate_wandermantium_ore"),
				new BlockItem(QcFabricCustomModBlocks.DEEPSLATE_WANDERMANTIUM_ORE, new Item.Properties().tab(QcFabricCustomModTabs.TAB_QC_1_CUSTOM)));
		WANDERMANTIUM_AXE = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_axe"), new WandermantiumAxeItem());
		WANDERMANTIUM_PICKAXE = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_pickaxe"), new WandermantiumPickaxeItem());
		WANDERMANTIUM_SWORD = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_sword"), new WandermantiumSwordItem());
		WANDERMANTIUM_SHOVEL = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_shovel"), new WandermantiumShovelItem());
		WANDERMANTIUM_HOE = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_hoe"), new WandermantiumHoeItem());
		WANDERMANTIUM_ARMOR_HELMET = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_armor_helmet"), new WandermantiumArmorItem.Helmet());
		WANDERMANTIUM_ARMOR_CHESTPLATE = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_armor_chestplate"), new WandermantiumArmorItem.Chestplate());
		WANDERMANTIUM_ARMOR_LEGGINGS = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_armor_leggings"), new WandermantiumArmorItem.Leggings());
		WANDERMANTIUM_ARMOR_BOOTS = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_armor_boots"), new WandermantiumArmorItem.Boots());
		CHOCY_MILK = Registry.register(Registry.ITEM, new ResourceLocation(QcFabricCustomMod.MODID, "chocy_milk"), new ChocyMilkItem());
	}
}
