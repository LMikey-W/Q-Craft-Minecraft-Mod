
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.qcfabriccustom.init;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.qcfabriccustom.QcFabricCustomMod;

public class QcFabricCustomModPotions {
	public static Potion WANDERING;

	public static void load() {
		WANDERING = Registry.register(Registry.POTION, new ResourceLocation(QcFabricCustomMod.MODID, "wandering"),
				new Potion(new MobEffectInstance(MobEffects.BLINDNESS, 3600, 0, false, true), new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 3600, 2, false, true)));
	}
}
