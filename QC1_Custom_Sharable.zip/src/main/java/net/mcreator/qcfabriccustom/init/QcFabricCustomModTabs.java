
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.qcfabriccustom.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;

public class QcFabricCustomModTabs {
	public static CreativeModeTab TAB_QC_1_CUSTOM;

	public static void load() {
		TAB_QC_1_CUSTOM = FabricItemGroupBuilder.create(new ResourceLocation("qc_fabric_custom", "qc_1_custom")).icon(() -> new ItemStack(QcFabricCustomModItems.WANDERMANTIUM_INGOT)).build();
	}
}
