
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.qcfabriccustom.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.qcfabriccustom.block.WandermantiumOreBlock;
import net.mcreator.qcfabriccustom.block.WandermantiumBlockBlock;
import net.mcreator.qcfabriccustom.block.DeepslateWandermantiumOreBlock;
import net.mcreator.qcfabriccustom.QcFabricCustomMod;

public class QcFabricCustomModBlocks {
	public static Block WANDERMANTIUM_BLOCK;
	public static Block WANDERMANTIUM_ORE;
	public static Block DEEPSLATE_WANDERMANTIUM_ORE;

	public static void load() {
		WANDERMANTIUM_BLOCK = Registry.register(Registry.BLOCK, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_block"), new WandermantiumBlockBlock());
		WANDERMANTIUM_ORE = Registry.register(Registry.BLOCK, new ResourceLocation(QcFabricCustomMod.MODID, "wandermantium_ore"), new WandermantiumOreBlock());
		DEEPSLATE_WANDERMANTIUM_ORE = Registry.register(Registry.BLOCK, new ResourceLocation(QcFabricCustomMod.MODID, "deepslate_wandermantium_ore"), new DeepslateWandermantiumOreBlock());
	}

	public static void clientLoad() {
		WandermantiumBlockBlock.clientInit();
		WandermantiumOreBlock.clientInit();
		DeepslateWandermantiumOreBlock.clientInit();
	}
}
